# Volleyball > 2023-09-23 8:03pm
https://universe.roboflow.com/practicas-preprofesionales/volleyball-71fyc

Provided by a Roboflow user
License: CC BY 4.0

